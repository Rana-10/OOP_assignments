// Assignment # 03
// Muhammad Azmat
// i23-2651
// DS-C

#include <iostream>
#include <string>
#include <string.h>

using namespace std;

class product
{
private:
    int ID;
    char *name = new char;
    float price;
    int quantity;

public:
    product(int id = 0, char *naam = 0, float pricey = 0, int tadaad = 0) : ID(id), name(naam), price(pricey), quantity(tadaad)
    {
        name = new char[strlen(naam) + 1];
        strcpy(name, naam);
    }

    ~product() // destructor
    {
        delete[] name;
        ID = 0;
        price = 0;
        quantity = 0;
    }

    void set_product(int id, char *naam, float pricey, int tadaad)
    {
        ID = id;
        delete[] name;
        name = new char[strlen(naam) + 1];
        strcpy(name, naam); // name is destination and naam is src
        price = pricey;
        quantity = tadaad;
    }

    int get_ID() const
    {
        return ID;
    }

    char *get_name() const
    {
        return name;
    }

    float get_price() const
    {
        return price;
    }

    int get_quantity() const
    {
        return quantity;
    }

    void add_product(int id, char *naam, float pricey, int tadaad)
    {
        ID = id;
        delete[] name;
        name = new char[strlen(naam) + 1];
        strcpy(name, naam);
        price = pricey;
        quantity = tadaad;
        return;
    }

    void remove_product(int id)
    {
        if (id != ID)
        {
            cout << "Invalid ID brother, try again " << endl;
        }
        else
        {
            if (ID == id)
            {
                ID = 0;
                delete[] name;
                name = nullptr;
                price = 0;
                quantity = 0;
                cout << "Product with ID " << id << " removed successfully! " << endl;
            }
        }
    }

    void remove_product(char *naam)
    {
        if (naam != name)
        {
            cout << "Invalid name, try again brother " << endl;
        }
        else
        {
            if (naam == name)
            {
                delete[] name;
                name = nullptr;
                price = 0;
                quantity = 0;
                ID = 0;
                cout << "Product with name " << naam << " has been removed succesfully!! " << endl;
            }
        }
    }

    void remove_product(int id, int count)
    {
        cout << "Welcome to removing product on basis of ID " << endl;
        if (id != ID)
        {
            cout << "Invalid ID, try again" << endl;
        }
        else
        {
            if (ID == id)
            {
                if (quantity >= count)
                {
                    quantity = quantity - count;
                    cout << "Your product with ID no: " << id << " has " << count << " units removed successfully ** " << endl;
                }
                else
                {
                    if (quantity < count)
                    {
                        cout << "You're entering an invalid amount, try again " << endl;
                    }
                }
            }
        }
    }

    void update_quantity(int id, int quantity_change)
    {
        if (ID != id)
        {
            cout << "You are entering an invalid ID, try again " << endl;
        }
        else
        {
            if (ID == id)
            {

                cout << "Type + if you want to increment the amount " << endl;
                cout << "Type - if you want to decrement the amount " << endl;
                char sign;
                cin >> sign;
                if (sign == '+')
                {
                    quantity = quantity + quantity_change;
                }
                else
                {
                    if (sign == '-')
                    {
                        if (quantity < quantity_change)
                        {
                            cout << "** Subtraction NOT Possible **" << endl;
                            exit(0);
                        }
                        else
                        {
                            quantity = quantity - quantity_change;
                        }
                    }
                    else
                    {
                        if (sign != '+' && sign != '-')
                        {
                            cout << "** ERROR. ENTER CORRECT OPERATOR ** " << endl;
                        }
                    }
                }
            }
        }
    }

    void display()
    {
        cout << "ID: " << ID << endl;
        cout << "Name: " << name << endl;
        cout << "Price: " << price << endl;
        cout << "Quantity: " << quantity << endl;
    }
};

class inventory
{
private:
    product *products = new product;
    int count; // number of prod in the inventory
    int size;

public:
    inventory(int sizee)
    {
        size = sizee;
        products = new product[size];
        count = 0;
    }

    ~inventory()
    {
        delete[] products;
        count = 0;
        size = 0;
    }

    void add_product(const product &prod)
    {
        if (size > count)
        {
            products[count++].set_product(prod.get_ID(), new char[strlen(prod.get_name() + 1)], prod.get_price(), prod.get_quantity());
            // strcpy(destination, src);
            // strcpy(const_cast<char *>(products[count - 1].get_name()), prod.get_name());
        }
        else
        {
            cout << "Cannot add more products, ** INVENTORY FULL ** " << endl;
        }
        return;
    }

    float calculate_inventory_val()
    {
        // we need to sum the prices of all products.
        // so loop chalein ge, till the count i.e. number of products

        float total_revenue = 0;
        cout << endl;
        cout << "Calculating total revenue ... " << endl;
        cout << endl;

        for (int i = 0; i < count; i++)
        {
            total_revenue = total_revenue + (products[i].get_price() * products[i].get_quantity());
        }
        return total_revenue;
    }

    product &get_product(int id)
    {
        for (int i = 0; i < count; i++)
        {
            if (id != products[i].get_ID())
            {
                cout << "ID doesn't match! " << endl;
                exit(0);
            }
            else
                return products[i];
            // object he return krwa rhe, tou so we can retrieve each individual component
        }
    }
};

int main()
{
    cout << "** WELCOME TO INVENTORY MANAGEMENT SYSTEM ** " << endl;

    product M4A4(7, const_cast<char *>("M4A4"), 97000, 2);

    // displaying the product details using the member functions.
    cout << "Product Details:" << endl;
    cout << "ID: " << M4A4.get_ID() << endl;
    cout << "Name: " << M4A4.get_name() << endl;
    cout << "Price: " << M4A4.get_price() << endl;
    cout << "Quantity: " << M4A4.get_quantity() << endl;
    cout << endl;

    // Updating the quantity of M4A4
    int new_amount = 5;
    M4A4.update_quantity(M4A4.get_ID(), new_amount);

    cout << "Updated Quantity of M4A4: " << M4A4.get_quantity() << endl;
    cout << endl;

    inventory ammo(5); // lets say ammo(bullets) 5 hain

    cout << "Adding M4A4 to the inventory *** " << endl;
    ammo.add_product(M4A4);
    cout << "hello";

    // float money = ammo.calculate_inventory_val();
    // cout << "Total Inventory Value (in Dollars):" << money << endl;

    return 0;
}
