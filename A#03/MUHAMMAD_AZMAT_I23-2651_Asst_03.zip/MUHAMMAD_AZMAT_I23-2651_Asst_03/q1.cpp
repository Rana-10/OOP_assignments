// Assignment # 03
// Muhammad Azmat
// i23-2651
// DS-C

#include <iostream>
#include <string>
#include <string.h>

using namespace std;

class ice_cream
{
private:
    // dynamically allocating memory to these 3 attributes;

    char *flavour = new char[20];
    char *topping = new char[20];
    char *serving_type = new char[20];
    bool is_ready;
    double price;

public:
    ice_cream() // default constructor
    {
        // flavour = '-';
        strcpy(flavour, "-");
        strcpy(topping, "-");
        strcpy(serving_type, "-");
        is_ready = false;
        price = 0;
    }

    ice_cream(char *flvr, char *topngs, char *servo_type, double pricey) // parametrised constructor
    {
        *flavour = *flvr;
        *topping = *topngs;
        *serving_type = *servo_type;
        price = pricey;
    }

    ice_cream(char *topngs, double pricey)
    {
        *topping = *topngs;
        price = pricey;
    }

    ice_cream(const ice_cream &icey_ice) // copy constructor
    {
        *flavour = *icey_ice.flavour;
        *topping = *icey_ice.topping;
        *serving_type = *icey_ice.serving_type;
        is_ready = icey_ice.is_ready;
        price = icey_ice.price;
    }

    ~ice_cream() // destructor
    {
        delete flavour;
        delete topping;
        delete serving_type;
        price = 0;
    }

    // making outline function prototypes;
    void set_flavour(char *flvr);
    void set_topping(char *topngs);
    void set_serving_type(char *servo_type);
    void set_price(float pricey);

    char *getflavour() const
    {
        return flavour;
    }

    char *gettopping() const
    {
        return topping;
    }

    char *get_serving_type() const
    {
        return serving_type;
    }

    double get_price() const
    {
        return price;
    }

    void make_icecream()
    {
        is_ready = true;
    }

    bool check_status()
    {
        return is_ready;
    }
};

void ice_cream ::set_flavour(char *flvr)
{
    delete[] flavour;
    flavour = new char[strlen(flvr) + 1];
    strcpy(flavour, flvr); // flvr is the src, flavour is the destination
}

void ice_cream ::set_topping(char *topngs)
{
    delete[] topping;
    topping = new char[strlen(topngs) + 1];
    strcpy(topping, topngs);
}

void ice_cream ::set_serving_type(char *servo_type)
{
    delete[] serving_type;
    serving_type = new char[strlen(servo_type) + 1];
    strcpy(serving_type, servo_type);
}

void ice_cream ::set_price(float pricey)
{
    price = pricey;
}

int main()
{
    cout << " ** WELCOME TO SOFT SWIRL ICE CREAM SHOP ** " << endl;

    ice_cream soft_swirl;

    soft_swirl.set_flavour(const_cast<char *>("Vanilla")); // we used const cast, which is basically used to change non-const class members inside a const member func
    soft_swirl.set_topping(const_cast<char *>("Crackers"));
    soft_swirl.set_serving_type(const_cast<char *>("Cup"));
    soft_swirl.set_price(280.5);

    soft_swirl.make_icecream(); // making the icecream

    bool isReady = soft_swirl.check_status(); // checking the status
    if (isReady)
    {
        cout << "Dear Customer! Your ice-cream is ready :) " << endl;
    }
    else
    {
        if (isReady == false)
            cout << "Please wait, Your ice-cream is still getting prepared!! " << endl;
    }

    cout << "Flavour: " << soft_swirl.getflavour() << endl; // displaying the details.
    cout << "Topping: " << soft_swirl.gettopping() << endl;
    cout << "Serving Type: " << soft_swirl.get_serving_type() << endl;
    cout << "Price: (in PKR) " << soft_swirl.get_price() << endl;

    return 0;
}