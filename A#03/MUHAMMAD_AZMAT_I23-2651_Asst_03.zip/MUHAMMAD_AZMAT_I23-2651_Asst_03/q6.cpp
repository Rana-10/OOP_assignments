// Assignment # 03
// Muhammad Azmat
// i23-2651
// DS-C

#include <iostream>
#include <string>
#include <string.h>
#include <cstring>

using namespace std;

class String
{
private:
    char *data;
    int length;

public:
    // making a default constructor

    String()
    {
        data = new char;
        length = 0;
    }

    String(int size)
    {
        data = new char;
        length = size;
    }

    String(char *str)
    {
        int s = sizeof(str);
        length = s;
        data = new char[length];
        strcpy(data, str);
    }

    String(const String &str) // this is our copy constructor
    {
        length = str.length;
        data = new char[length + 1];
        strcpy(data, str.data);
    }

    ~String() // destructor
    {
        delete[] data;
        data = nullptr;
        length = 0;
    }

    int str_length()
    {
        return length;
    }

    void clear()
    {
        length = 0;
        delete[] data;
        data = nullptr;
    }

    bool empty()
    {
        for (int i = 0; i < length; i++)
        {
            if (data[i] == '\0')
                return false;
            else
                return true;
        }
    }

    int char_at(char c)
    {
        for (int i = 0; i < length; i++)
        {
            if (data[i] == c)
            {
                return i;
            }
        }
        return -2; // if character not found
    }

    void to_upper_case()
    {
        for (int i = 0; i < length; ++i)
        {
            data[i] = toupper(data[i]);
            cout << data[i];
        }
    }

    void to_lower_case()
    {
        for (int i = 0; i < length; ++i)
        {
            data[i] = tolower(data[i]);
            cout << data[i];
        }
    }
};
int main()
{
    cout << "** WELCOME TO STRING CLASS PROGRAM ** " << endl;
    String sentence(10);
    String sentence2(const_cast<char *>("HI"));
    String sentence3(const_cast<char *>("hi"));

    sentence2.to_lower_case();
    cout << endl;
    sentence3.to_upper_case();
    cout << endl;

    // int num = sentence3.char_at('i');
    // cout << num << endl;

    return 0;
};