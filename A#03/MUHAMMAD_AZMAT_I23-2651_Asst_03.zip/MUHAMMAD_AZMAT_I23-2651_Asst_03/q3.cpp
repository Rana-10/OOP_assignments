// Assignment # 03
// Muhammad Azmat
// i23-2651
// DS-C

#include <iostream>
#include <string>

using namespace std;

class hotel_booking
{
private:
    string booking_id;
    string customer_name;
    string hotel_name;
    string room_type;
    string check_in;       // starting date
    string check_out;      // ending date of stay
    int stay_duration = 5; // days
    double room_rate;

public:
    int total_expense = 1;
    hotel_booking(string id, string name, string hotel, string room_typo, string ci, string co)
    {
        booking_id = id;
        customer_name = name;
        hotel_name = hotel;
        room_type = room_typo;
        check_in = ci;
        check_out = co;
    }

    string get_booking_id()
    {
        return booking_id;
    }

    void validate_booking_id() const
    {
        int count = 0;
        int sum = 0;

        if (booking_id.size() + 1 != 14) // we did + 1 as the counting starts from 0
        {
            cout << "Error! Follow the correct sequence !! " << endl;
            exit(0);
        }
        else
        {
            for (int i = 7; i <= 8; i++)
            {
                if ((booking_id[i] >= 32 && booking_id[i] <= 47) || (booking_id[i] >= 58 && booking_id[i] <= 64) || (booking_id[i] >= 91 && booking_id[i] <= 96) || (booking_id[i] >= 123 && booking_id[i] <= 126))
                {
                    count++;
                }
            }

            // now to check if the sum of last 4 digits is less than 18
            // we convert last 4 string characters to int digits

            string last_4 = booking_id.substr(9, 4);
            int last_4_dig = stoi(last_4);
            // cout << last_4_dig; // checking the extraction

            // using the concept of mod div to check to separate each number and then checking the sum condition

            int sum = 0;
            while (last_4_dig != 0)
            {
                sum += last_4_dig % 10;
                last_4_dig /= 10;
            }

            if (sum >= 18)
            {
                cout << "** SUM HAS EXCEEDED THE LIMIT 18, Try again ** " << endl;
                exit(0);
            }
            else
            {
                cout << "Sum all okay! " << endl;
            }

            if (count != 2 || sum >= 18)
            {
                cout << "** Enter a correct special character ** ";
                exit(0);
            }

            else
            {
                cout << "Both the sum and special characters' condition is met, You can continue the procedure " << endl;
                cout << endl;
                cout << endl;
            }
        }
    }
    double calculate_room_rate() const
    {
        // as it is const, so we cannot assign, mod any variables in private scope.

        if (room_type == "single" || room_type == "Single")
        {
            cout << "The room rate for a single bedroom is 1000 " << endl;
            return 1000;
        }
        if (room_type == "double" || room_type == "Double")
        {
            cout << "The room rate for a double bedroom is 2000 " << endl;
            return 2000;
        }
        if (room_type == "suite" || room_type == "Suite")
        {
            cout << "The room rate for suite bedrooms are 3500 " << endl;
            return 3500;
        }
        else
        {
            cout << "Not a valid choice, try again! " << endl;
            return 0; // for invalid inputs;
        }
    }

    int calculate_total_cost() const
    {
        // the cost of staying 24 hrs(1 day ) in hotel = 5000;
        int room_cost = calculate_room_rate(); // automatic type demotion
        cout << endl;
        int total_expense = stay_duration * room_cost;
        return total_expense;
    }

    string get_booking_details() const
    {
        cout << "Your Booking ID is " << booking_id << endl;
        cout << "The Customers' name is " << customer_name << endl;
        cout << "The Hotels' name is " << hotel_name << endl;
        cout << "The Room type is " << room_type << endl;
        cout << "The Check in date was " << check_in << endl;
        cout << "The Check out date was " << check_out << endl;
        cout << "The Duration of your stay was " << stay_duration << " Days " << endl;
        // cout << "The Total expense of the stay: " << total_expense << endl;

        return booking_id, customer_name, hotel_name, room_type, check_in, check_out, to_string(stay_duration), to_string(room_rate), to_string(total_expense);
    }

    void update_booking_info(string new_check_in, string new_check_out, int new_stay_duration)
    {
        cout << "** WELCOME TO THE UPDATE PANEL ** " << endl;
        check_in = new_check_in;
        check_out = new_check_out;
        stay_duration = new_stay_duration;
        calculate_total_cost();
        cout << endl;
    }
};

int main()
{
    string ID;
    string your_name;
    string type_of_rooom;
    string name_of_hotel = "Marriot";
    string check_in_date = "5 March Tuesday";
    string check_out_date = "10 March Sunday";

    cout << "*** HOTEL MANAGEMENT SYSTEM *** " << endl;
    cout << endl;
    cout << "Dear Customer! Please enter the booking ID " << endl;
    cin >> ID;
    cout << "Enter your name" << endl;
    cin >> your_name;
    cout << "Enter the room you want to have: single, double or suite " << endl;
    cin >> type_of_rooom;

    hotel_booking marriot(ID, your_name, name_of_hotel, type_of_rooom, check_in_date, check_out_date);

    marriot.validate_booking_id();
    marriot.calculate_room_rate();
    int c = marriot.calculate_total_cost();
    marriot.get_booking_details();
    cout << "The Total cost for your stay will be " << c << endl;

    // updating panel prompt!

    // marriot.update_booking_info("3 march", "6 march", 3);
    // int x = marriot.calculate_total_cost();
    // cout << "The Total cost for your stay will be " << x << endl;

    return 0;
}