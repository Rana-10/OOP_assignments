// Assignment # 03
// Muhammad Azmat
// i23-2651
// DS-C

#include <iostream>
#include <string>
#include <string.h>
#include <cstring>

using namespace std;

class library
{
private:
    char *book_title = new char[20];
    char *author = new char[20];
    int book_id;
    int quantity; // no of copies of the book
    float price;
    static int total_no_of_books; // declaring the static variable

public:
    // first, I'm making a constructor to intialise
    library()
    {
        strcpy(book_title, "nill");
        strcpy(author, "nill");
        book_id = 0;
        quantity = 0;
        price = 0;
        total_no_of_books = 0;
    }

    // setters

    void set_book_title(const char *title)
    {
        delete[] book_title;
        book_title = new char[strlen(title) + 1]; // dynamically allocating the space
        strcpy(book_title, title);
        return;
    }

    void set_authorr(const char *author_name)
    {
        delete[] author;
        author = new char[strlen(author_name) + 1]; // dynamically allocating the space
        //   strcpy(dest, src);
        strcpy(author, author_name);
        return;
    }

    void set_book_id(int id)
    {
        book_id = id;
        return;
    }

    void set_quantity(int tadaad)
    {
        quantity = tadaad;
        return;
    }

    void set_price(float priceyy)
    {
        price = priceyy;
        return;
    }

    static void set_total_books(int total_books)
    {
        total_no_of_books = total_books;
        return;
    }

    void calc_total_price()
    {
    }

    // getters

    char *get_book_title()
    {
        return book_title;
    }

    char *get_author()
    {
        return author;
    }

    int get_book_id()
    {
        return book_id;
    }

    int get_quantity()
    {
        return quantity;
    }

    float get_price()
    {
        return price;
    }

    static int get_total_books()
    {
        return total_no_of_books;
    }

    // now implementing the following functions in global scope

    library get_book_at(library books[100], int indxx)
    {
        int size = 100;
        for (int i = 0; i < size; i++)
        {
            if (i == indxx)
            {
                return books[i]; // returning the object
            }
            else
            {
                cout << "__BOOK NOT FOUND__ " << endl;
                return library();
            }
        }
    }

    void add_book(library books[100], library new_book)
    {
        int size = 100;
        if (total_no_of_books < size)
        {
            books[total_no_of_books] = new_book;
            total_no_of_books++;
        }
        else
        {
            cout << "Library is full, ** TRY AGAIN ** " << endl;
        }

        return;
    }

    void remove_book(library books[100], int id)
    {
        int size = 100;
        for (int i = 0; i < total_no_of_books; i++)
        {
            if (books[i].get_book_id() == id)
            {
                delete[] book_title;
                book_title = nullptr;
                delete[] author;
                author = nullptr;
                book_id = 0;
                quantity = 0;
                quantity = 0;
                price = 0;
                total_no_of_books--;
                cout << "The Book with ID " << id << " has been removed succesfully. " << endl;
                return;
            }
            else
            {
                cout << "Book with this ID doesn't exist. Please Try Again. " << endl;
                return;
            }
        }
    }

    void sort_by_title(library books[100])
    {
        int size = 100;
        library temp;

        // strcmp is a function used to compare strings; character by character and returns int value
        for (int i = 0; i < size - 1; i++)
        {
            for (int j = i + 1; j < size; j++)
            {
                if (strcmp(books[j].get_book_title(), books[i].get_book_title()) < 0)
                {
                    temp = books[i];
                    books[i] = books[j];
                    books[j] = temp;
                }
            }
        }
        return;
    }

    void sort_by_author(library books[100])
    {
        int size = 100;
        library temp;

        // strcmp is a function used to compare strings; character by character and returns int value
        for (int i = 0; i < size - 1; i++)
        {
            for (int j = i + 1; j < size; j++)
            {
                if (strcmp(books[j].get_author(), books[i].get_author()) < 0)
                {
                    temp = books[i];
                    books[i] = books[j];
                    books[j] = temp;
                }
            }
        }
        return;
    }

    void sort_by_price(library books[100])
    {
        int size = 100;
        library temp;

        // strcmp is a function used to compare strings; character by character and returns int value
        for (int i = 0; i < size - 1; i++)
        {
            for (int j = i + 1; j < size; j++)
            {
                if (books[j].get_price() < books[i].get_price())
                {
                    temp = books[i];
                    books[i] = books[j];
                    books[j] = temp;
                }
            }
        }
        return;
    }

    bool search_by_title(library books[100], char *title_name)
    {
        int size = 100;
        for (int i = 0; i < size; i++)
        {
            // using strcmp to compare our two strings
            // if they are equal, it will return an integer 0
            if (strcmp(books[i].get_book_title(), title_name) == 0)
            {
                return true;
            }
        }
        return false;
    }

    library most_expensive_book(library books[100])
    {
        int size = 100;
        library mehangi_tareen = books[0];

        for (int i = 0; i < size; i++)
        {
            if (books[i].get_price() > mehangi_tareen.get_price())
            {
                mehangi_tareen.set_price(books[i].get_price());
            }
        }

        return mehangi_tareen;
    }
};

// defining the static variable

int library ::total_no_of_books = 0;

int main()
{
    library nuces[100];
    cout << "** WELCOME TO THE PROGRAM ** " << endl;
    cout << endl;

    nuces[0].set_book_title("RDR2");
    nuces[0].set_authorr("Arthur Morgan");
    nuces[0].set_book_id(44);
    nuces[0].set_quantity(10);
    nuces[0].set_price(790.5);
    library::set_total_books(1); // we will increment total number of books as we go on

    nuces[1].set_book_title("Forza Horizon 4");
    nuces[1].set_authorr("Vortex");
    nuces[1].set_book_id(45);
    nuces[1].set_quantity(5);
    nuces[1].set_price(832.75);
    library::set_total_books(2);

    // displaying

    cout << "Books in the library:" << endl;
    for (int i = 0; i < library::get_total_books(); ++i)
    {
        cout << "Book ID: " << nuces[i].get_book_id() << endl;
        cout << "Title: " << nuces[i].get_book_title() << endl;
        cout << "Author: " << nuces[i].get_author() << endl;
        cout << "Quantity: " << nuces[i].get_quantity() << endl;
        cout << "Price: (in PKR)" << nuces[i].get_price() << endl;
        cout << endl;
        cout << endl;
        cout << endl;
    }

    // Searching for a book by title
    char book_keyword[] = "RDR2";
    if (nuces[0].search_by_title(nuces, book_keyword))
    {
        cout << "CONGRATULATIONS!! Book with title " << book_keyword << " found in the library." << endl;
    }
    else
    {
        cout << "UNFORTUNATELY!! Book with title " << book_keyword << " has not been found in the library." << endl;
    }

    // code for removing a book

    int book_id_to_remove = 45;
    for (int i = 0; i < library::get_total_books(); ++i)
    {
        if (nuces[i].get_book_id() == book_id_to_remove)
        {
            nuces[i].remove_book(nuces, book_id_to_remove);
            break;
        }
    }
    cout << endl;
    cout << endl;
    // most expensive book

    library mehangi_qeemti_kitab = nuces[0].most_expensive_book(nuces);
    cout << "Most expensive book (in PKR) in Library is: " << mehangi_qeemti_kitab.get_book_title() << endl;

    return 0;
}
