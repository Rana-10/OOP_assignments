// Assignment # 03
// Muhammad Azmat
// i23-2651
// DS-C

#include <iostream>
#include <string>
#include <string.h>

using namespace std;

class student
{
private:
    int student_id;
    string name;
    string *course_codes;
    int no_of_courses = 10;
    int *course_grades;
    float gpa;

public:
    // making a constructor
    student(int id, string f_n, int num_of_courz)
    {
        student_id = id;
        name = f_n;
        course_codes = new string[num_of_courz];
        course_grades = new int[num_of_courz];
        no_of_courses = 0;
    }

    ~student()
    {
        student_id = 0;
        name = "-";
        delete[] course_codes;
        course_codes = nullptr;
        delete[] course_grades;
        course_grades = nullptr;
        gpa = 0;
        no_of_courses = 0;
    }
    // setters
    void set_student_id(int id);
    void set_name(string first_name);
    void set_course_grade(string cc, int grade);
    void add_course(string cc, int grade);
    float calc_gpa();

    // getters
    int get_student_id();
    string get_name();
    int get_num_of_courses();
    string get_course_code(int i);
    int get_course_grade(int i);
    float get_gpa();
};

void student ::set_student_id(int id)
{
    student_id = id;
    return;
}

void student ::set_name(string first_name)
{
    name = first_name;
    return;
}

void student ::set_course_grade(string cc, int grade)
{
    for (int i = 0; i < no_of_courses; i++)
    {
        if (course_codes[i] == cc)
        {
            course_grades[i] = grade;
        }
    }
    return;
}

void student::add_course(string cc, int grade)
{
    if (no_of_courses >= 10)
    {
        cout << "Maximum number of courses reached!" << endl;
        return;
    }

    course_codes[no_of_courses] = cc;
    no_of_courses++;
    student::set_course_grade(cc, grade);
    // calc_gpa();
    return;
}

float student ::calc_gpa()
{
    float final_sum = 0;

    // calculating the sum(int) of all the courses registered
    for (int i = 0; i < no_of_courses; i++)
    {
        final_sum = final_sum + course_grades[i];
    }

    if (no_of_courses <= 0)
    {
        cout << "Since you've selected no courses; hence your gpa will be ZERO " << endl;
        gpa = 0;
    }
    else
    {
        gpa = final_sum / no_of_courses;
    }
    return gpa;
}

int student ::get_student_id()
{
    return student_id;
}

string student ::get_name()
{
    return name;
}

int student ::get_num_of_courses()
{
    return no_of_courses;
}

string student ::get_course_code(int i)
{
    return course_codes[i];
}

int student ::get_course_grade(int i)
{
    return course_grades[i];
}

float student ::get_gpa()
{
    return gpa;
}

// now we are making global functions

student get_student_at(student _students[], int indxx)
{
    return _students[indxx];
}

float calc_class_gpa(student _students[], int students_num)
{
    float class_gpa = 0;
    for (int i = 0; i < students_num; i++)
    {
        class_gpa = class_gpa + _students[i].calc_gpa();
    }
    float avg_gpa = class_gpa / students_num;

    return avg_gpa;
}

float get_max_gpa(student _students[], int students_num)
{
    float max_gpa = 0;
    for (int i = 0; i < students_num; i++)
    {
        if (_students[i].get_gpa() > max_gpa)
        {
            max_gpa = _students[i].get_gpa();
        }
    }
    return max_gpa;
}

float get_min_gpa(student _students[], int students_num)
{
    float min_gpa = 10;
    for (int i = 0; i < students_num; i++)
    {
        if (_students[i].get_gpa() < min_gpa)
        {
            min_gpa = _students[i].get_gpa();
        }
    }

    return min_gpa;
}

void print_student_record(student _student)
{
    cout << "ID: " << _student.get_student_id() << endl;
    cout << "Name: " << _student.get_name() << endl;
    for (int i = 0; i < _student.get_num_of_courses(); i++)
    {
        cout << "Course Codes : " << _student.get_course_code(i) << endl;
        cout << "Grades : " << _student.get_course_grade(i) << endl;
    }
    cout << "GPA: " << _student.get_gpa() << endl;
    cout << endl;

    return;
}

void print_all_student_records(student _students[], int students_num)
{
    cout << "The details of students are as follows: " << endl;
    for (int i = 0; i < students_num; i++)
    {
        cout << "Student: " << i + 1 << endl;
        print_student_record(_students[i]);
        cout << endl;
        cout << endl;
    }
    return;
}

int main()
{
    cout << "** WELCOME TO THE PROGRAM ** " << endl;
    const int no_of_good_bachas = 3;
    student achey_bachey[no_of_good_bachas]{student(23, "AbuBakar", 3), student(24, "Ismail", 4), student(25, "Umar", 5)};

    for (int i = 0; i < 3; i++)
    {
        achey_bachey[i].add_course("MT-1008", 3);
        achey_bachey[i].add_course("CS-1005", 1);
        achey_bachey[i].add_course("SS-1002", 4);
        // achey_bachey[i].calc_gpa();
    }

    // achey_bachey[0].add_course("MT-1008", 3);

    cout << "The Student Record of these students is as follows: " << endl;

    print_student_record(achey_bachey[0]);
    cout << endl;
    print_student_record(achey_bachey[1]);
    cout << endl;
    print_student_record(achey_bachey[2]);
    cout << endl;

    return 0;
}