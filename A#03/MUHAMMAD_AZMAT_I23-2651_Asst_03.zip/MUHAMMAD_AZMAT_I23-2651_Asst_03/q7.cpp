// Assignment # 03
// Muhammad Azmat
// i23-2651
// DS-C

#include <iostream>
#include <string>
#include <string.h>
#include <ctime>

using namespace std;

class minesweeper
{

private:
    int **grid;
    int size;
    int mines;

public:
    minesweeper(int sizee, int minez) // default constructor
    {
        if (sizee < 7)
        {
            cout << "Sorry, The minimum size has to be 7 or above :( " << endl;
            exit(0);
        }
        else
        {
            // making a 2D array and initialising all the values to 0
            size = sizee;
            mines = minez;
            grid = new int *[size];
            for (int i = 0; i < size; i++)
            {
                grid[i] = new int[size];
                for (int j = 0; j < size; j++)
                {
                    grid[i][j] = 0;
                }
            }

            // now that grid is formed, place mines :p
            mines_placement();
            return;
        }
    }

    ~minesweeper()
    {
        for (int i = 0; i < size; i++)
        {
            delete[] grid[i];
        }
        delete[] grid;
        grid = nullptr;
        size = 0;
        mines = 0;
    }

    void reset()
    {
        // we want to reset the game, meaning board ka size wohi rahe, mines k jagah change ho jae
        // deleting old board
        deallocation();
        allocation();
        mines_placement();
    }

    void reveal_all()
    {
        // we have to reveal all cells without mines, means completing the game
        for (int i = 0; i < size; i++)
        {
            for (int j = 0; j < size; j++)
            {
                if (grid[i][j] != -1)
                {
                    grid[i][j] = 1;
                    //  cout << grid[i][j] << " ";
                }
            }
            cout << endl;
        }
        display_grid();
    }

    bool reveal_cell(int r, int c)
    {
        if (r > size || c > size)
        {
            cout << "** Invalid ROW or COLUMN ** " << endl;
            exit(0);
        }
        reveal_all();
        for (int i = 0; i < size; i++)
        {
            for (int j = 0; j < size; j++)
            {
                if (grid[r][c] != -1 && grid[r][c] >= 0)
                {
                    return true;
                }
                else
                {
                    // reveal_all();
                    return false;
                }
            }
        }
    }

    void flag_cell(int r, int c)
    {
        if (r > size || c > size)
        {
            cout << "** Invalid ROW or COLUMN ** " << endl;
            exit(0);
        }
        else
        {
            grid[r][c] = -2;
            display_grid();
            return;
        }
    }

    bool check_win()
    {
        for (int i = 0; i < size; i++)
        {
            for (int j = 0; j < size; j++)
            {
                if (grid[i][j] == 0)
                {
                    return false;
                }
            }
        }
        return true;
    }

    void display_grid()
    {

        for (int i = 0; i < size; i++)
        {
            for (int j = 0; j < size; j++)
            {
                if (grid[i][j] == -1) // representing mines
                {
                    cout << " * ";
                }
                else
                {
                    if (grid[i][j] == -2) // representing flag
                    {
                        cout << " F ";
                    }
                    else
                    {
                        if (grid[i][j] == 1)
                        {
                            cout << " - ";
                        }
                        else
                        {
                            cout << " # "; // for error handling purposes
                        }
                    }
                }
            }
            cout << endl;
        }
        return;
    }

    void allocation()
    {
        grid = new int *[size];
        for (int i = 0; i < size; i++)
        {
            grid[i] = new int[size];
            for (int j = 0; j < size; j++)
            {
                grid[i][j] = 0;
            }
        }
    }

    void deallocation()
    {
        for (int i = 0; i < size; i++)
        {
            delete[] grid[i];
        }
        delete[] grid;
    }

    void mines_placement()
    {
        srand(time(0));
        int flag = 0;
        // randomly spawning the mines
        for (int i = 0; i < mines; i++)
        {
            int x_coordinate = rand() % size; // placing it inside loop, so after iteration, new random coordinates are generated
            int y_coordinate = rand() % size;

            if (flag > mines)
            {
                cout << "** CANNOT ADD MORE MINES ** " << endl;
                return;
            }
            else
            {
                if (flag < mines)
                {
                    grid[x_coordinate][y_coordinate] = -1;
                    flag++;
                }
            }
        }
        return;
    }
};

int main()
{
    int s; // s for size and m for mines
    int m;

    cout << "*** WELCOME TO MINESWEEPER *** " << endl;
    cout << "Enter the size of the grind( minimum = 7 or above )" << endl;
    cin >> s;
    cout << "Enter the number of mines *_* " << endl;
    cin >> m;

    // calling the minesweeper constructor
    minesweeper game(s, m);
    game.reset(); // changing the location of mines
                  // game.reveal_all(); // reveals the position of everything(mines, normal spots) in game
    bool suspense = game.reveal_cell(2, 2);
    cout << suspense << endl; // returning 1 means at (2,2) it is a safe spot and not a mine
    cout << endl;
    cout << endl;
    game.flag_cell(6, 6); // on corner a F will appear, which indicates a flag
    cout << endl;
    cout << endl;
    bool win = game.check_win();
    cout << win << endl; // returning 1 meaning everything is fine
    cout << endl;
    cout << endl;
    game.display_grid();

    return 0;
}