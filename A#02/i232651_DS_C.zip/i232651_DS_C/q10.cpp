// Assignment # 02
// Muhammad Azmat
// 23I-2651
// DS-C

#include <iostream>
#include <ctime>
using namespace std;

void allocating_memory(int **&arr, int rows, int cols, int count = 0);
void taking_input(int **arr, int rows, int cols, int count1 = 0, int count2 = 0);
int calculateHourGlassSum(int **arr, int row, int cols);
void max(int **arr, int row, int col, int &maximum_sum, int &maximum_row, int &maximum_col);
void output(int **arr, int rows, int cols, int count1, int count2);
void deallocating_memeory(int **arr, int rows);

int main()
{
    srand(time(0));
    int r = 0;
    int c = 0;

    cout << "** WELCOME TO THE PROGRAM ** " << endl;
    cout << "Enter the number of rows " << endl;
    cin >> r;
    cout << "Enter the number of columns " << endl;
    cin >> c;

    if (c == 6 && r == 6)
    {

        int **array = new int *[r];
        allocating_memory(array, r, c);
        taking_input(array, r, c, 0, 0);
        cout << "Entered array:" << endl;
        output(array, r, c, 0, 0);
        int maxsum = 0, maxrow = 0, maximum_col = 0;
        max(array, 0, 0, maxsum, maxrow, maximum_col);
        cout << "Maximum hourglass sum: " << maxsum << endl;
        deallocating_memeory(array, r);
    }
    else
    {
        cout << "Please enter an array of size 6x6" << endl;
    }

    return 0;
}

void allocating_memory(int **&arr, int rows, int cols, int count)
{
    if (count == rows)
    {
        return;
    }
    arr[count] = new int[cols];
    allocating_memory(arr, rows, cols, count + 1);
}

void taking_input(int **arr, int rows, int cols, int count1, int count2)
{
    if (count1 == rows)
    {
        return;
    }

    if (count2 == cols)
    {
        taking_input(arr, rows, cols, count1 + 1, 0);
        return;
    }

    arr[count1][count2] = rand() % 10;
    taking_input(arr, rows, cols, count1, count2 + 1);
}

int calculateHourGlassSum(int **arr, int row, int cols)
{
    if (row + 2 >= 6 || cols + 2 >= 6)
    {
        return 0;
    }

    int summ = 0;
    summ += arr[row][cols] + arr[row][cols + 1] + arr[row][cols + 2];
    summ += arr[row + 1][cols + 1];
    summ += arr[row + 2][cols] + arr[row + 2][cols + 1] + arr[row + 2][cols + 2];

    return summ;
}

void max(int **arr, int row, int cols, int &maximum_sum, int &maximum_row, int &maximum_col)
{
    if (row > 3)
    {
        // Base case
        return;
    }

    if (cols > 3)
    {
        max(arr, row + 1, 0, maximum_sum, maximum_row, maximum_col);
        return;
    }

    int sum = calculateHourGlassSum(arr, row, cols);
    if (sum > maximum_sum)
    {
        maximum_sum = sum;
        maximum_row = row;
        maximum_col = cols;
    }
    max(arr, row, cols + 1, maximum_sum, maximum_row, maximum_col);
}

void output(int **arr, int rows, int cols, int count1, int count2)
{
    if (count1 == rows)
    {
        return;
    }

    if (count2 == cols)
    {
        cout << endl;
        output(arr, rows, cols, count1 + 1, 0);
        return;
    }
    cout << arr[count1][count2] << " ";
    output(arr, rows, cols, count1, count2 + 1);
}

void deallocating_memeory(int **arr, int rows)
{
    if (rows <= 0)
        return;
    else
        delete[] arr[rows - 1];
    deallocating_memeory(arr, rows - 1);
}