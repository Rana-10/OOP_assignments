// Assignment # 02
// Muhammad Azmat
// 23I-2651
// DS-C

#include <iostream>
#include <string>

using namespace std;

void diamond_printing(int count);
void upper_portion(int r, int c, int count);
void lower_portion(int r, int c, int count);

int main()
{
    int num = 10;
    do
    {
        cout << "Enter hollow diamond size brother ";
        cin >> num;
    } while (num <= 0);
    diamond_printing(num);
}

void diamond_printing(int count)
{
    static int rows = 0, col = 0;

    if (rows < (2 * count))
    {
        if (rows < count)
        {
            upper_portion(rows, col, count);
        }
        else
            lower_portion(rows, col, count);
        rows++;
        cout << endl;
        diamond_printing(count);
    }
    else
        return;
}

void upper_portion(int r, int c, int count)
{
    if (c < (2 * count))
    {
        if (r + c <= count - 1 || (r + count) <= c)
        {
            cout << "*";
        }
        else
            cout << " ";
    }
    else
        return;
    c++;
    upper_portion(r, c, count);
}

void lower_portion(int r, int c, int count)
{

    // base case
    if (count >= r && count >= c)
    {

        return;
    }
    else
    {
        cout << "*";
        lower_portion(r, c, count + 1);
    }
}

// if (c < (2 * count))
// {
//     if (r >= (2 * count - 1) - c)
//         cout << "*";
//     else if (r >= c)
//         cout << "*";
//     else
//         cout << "*";
// }
// else
//     return;
// c++;
// lower_portion(r, c, count);