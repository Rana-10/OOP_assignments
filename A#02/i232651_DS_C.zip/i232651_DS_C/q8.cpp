// Assignment # 02
// Muhammad Azmat
// 23I-2651
// DS-C

#include <iostream>
#include <ctime>
using namespace std;

void upper_portion(int len1, char smbol, int count = 1);
void lower_part(int len1, char smbol, int count1 = 1);
void times_print(int leng, char smbool, int count = 0);

int main()
{

    int length;
    char character = '+';

    cout << "Enter the length of the pattern" << endl;
    cin >> length;

    if (length > 0)
    {
        if (length % 2 == 0)
        {
            length = length + 1;
        }

        cout << "Enter the character brother " << endl;
        cin >> character;

        upper_portion(length, character);
        cout << endl;
        lower_part(length, character);
    }
    else
    {
        cout << " Invalid input, please try again " << endl;
    }
    return 0;
}

void upper_portion(int len1, char smbol, int count)
{
    // base case
    if (count >= len1)
    {
        return;
    }
    else
    {
        if (count == 1)
        {
            times_print(len1 * 2, smbol);
            cout << endl;
        }

        times_print(count + 1, smbol);
        times_print(len1 - count - 1, ' ');
        times_print(len1 - count, smbol);

        if (len1 == count + 1)
        {
            times_print(len1 - 1, smbol);
            return;
        }

        times_print(count - 1, ' ');
        cout << smbol;
        cout << endl;

        upper_portion(len1, smbol, count + 1);
    }
}

void lower_part(int len1, char smbol, int count1)
{
    if (count1 >= len1)
    {
        return;
    }

    else
    {

        cout << smbol << " ";
        if (len1 == count1 + 1)
        {
            times_print(len1 - 1, smbol);
        }

        times_print(len1 - count1 - 1, ' ');
        times_print(count1 + 1, smbol);
        if (len1 != count1 + 1)
        {
            times_print(count1 - 1, ' ');
        }
        times_print(len1 - count1 - 1, smbol);

        if (len1 != count1 + 1)
            cout << smbol;
        cout << endl;

        lower_part(len1, smbol, count1 + 1);
    }
}

void times_print(int leng, char smbool, int count)
{
    if (count >= leng)
    {
        return;
    }

    else
    {
        // upper_portion(leng, smbool, count);
        // lower_part(leng, smbool, leng - count);
        // cout << endl;
        cout << smbool << " ";
        times_print(leng, smbool, count + 1);
    }
}