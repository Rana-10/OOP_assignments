// Assignment # 02
// Muhammad Azmat
// 23I-2651
// DS-C

#include <iostream>
#include <string>

using namespace std;

bool isbalanced(string inp, int i, int j);

int main()
{
    // while (true)
    // {
    cout << "Enter the string you want to check the bracketing operators for " << endl;
    string input;
    cin >> input;

    bool ans = isbalanced(input, 0, input.length() - 1);

    if (ans)
    {
        cout << "The string has proper balancing done! " << endl;
    }
    else
        cout << "The string lacks proper balancing! " << endl;

    cout << endl;
    // }

    return 0;
}

bool isbalanced(string inp, int i, int j)
{
    // base case
    if (i >= j)
    {
        return true;
    }

    if ((inp[i] == '(' && inp[j] == ')') || (inp[i] == '{' && inp[j] == '}') || (inp[i] == '[' && inp[j] == ']'))
    {
        return isbalanced(inp, i + 1, j - 1);
    }

    else
        return false;
}