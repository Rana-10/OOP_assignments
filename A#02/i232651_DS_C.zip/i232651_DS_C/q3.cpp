#include <iostream>
#include <string>

using namespace std;

int count_routes(int street, int avenue);

int main()
{

    int strt = 3;
    int avnue = 2;

    cout << "** Welcome to KAREL THE ROBO Game ** " << endl;
    int routes = count_routes(strt, avnue);
    cout << "The total number of routes for the selected path is " << routes << endl;

    return 0;
}

int count_routes(int street, int avenue)
{
    // Base cases
    if (street == 1 && avenue == 1)
    {
        return 1;
    }

    if (street == 0 || avenue == 0)
    {
        return 0;
    }

    // Recursive calls
    int route_1 = count_routes(street - 1, avenue);
    int route_2 = count_routes(street, avenue - 1);

    // Summing up the routes
    return route_1 + route_2;
}
