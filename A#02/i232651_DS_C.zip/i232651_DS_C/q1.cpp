// Assignment # 02
// Muhammad Azmat
// 23I-2651
// DS-C

#include <iostream>
#include <string>
#include <string.h>

using namespace std;

string soundex(const string &name);
char remaining_part(const string &rem_p, int flag = 0);
int assignment(char to_encode, int count = 1);

int main()
{
    string to_send = "Muhammad";
    string ans;
    ans = soundex(to_send);
    cout << ans << endl;

    char l_o = remaining_part(to_send);
    cout << l_o;

    return 0;
}

string soundex(const string &name)
{
    int flag1 = 1;

    string first_letter = name.substr(0, 1);
    return first_letter;
}

int assignment(char to_encode, int count)
{
    // if (count > to_encode.length())
    // {
    //     return count;
    // }

    // char encoded = to_encode.substr(count++, 1);
    int storage;

    if (to_encode == 'a' || to_encode == 'e' || to_encode == 'i' || to_encode == 'o' || to_encode == 'u' || to_encode == 'h' || to_encode == 'w' || to_encode == 'y')
    {
        storage = 0;
        cout << storage;
        return storage;
    }

    if (to_encode == 'b' || to_encode == 'f' || to_encode == 'p' || to_encode == 'v')
    {
        storage = 1;
        cout << storage;
        return storage;
    }

    if (to_encode == 'c' || to_encode == 'g' || to_encode == 'j' || to_encode == 'k' || to_encode == 'q' || to_encode == 's' || to_encode == 'x' || to_encode == 'z')
    {
        storage = 2;
        cout << storage;
        return storage;
    }

    if (to_encode == 'd' || to_encode == 't')
    {
        storage = 3;
        cout << storage;
        return storage;
    }

    if (to_encode == 'm' || to_encode == 'n')
    {
        storage = 4;
        cout << storage;
        return storage;
    }

    if (to_encode == 'l')
    {
        storage = 5;
        cout << storage;
        return storage;
    }

    if (to_encode == 'r')
    {
        storage = 6;
        cout << storage;
        return storage;
    }
}

char remaining_part(const string &rem_p, int flag)
{
    // base case
    if (flag > rem_p.length())
    {
        return flag;
    }
    else
    {
        char rm = remaining_part(rem_p.substr(++flag, 1));
        assignment(rm);
        return rm;
    }
}
