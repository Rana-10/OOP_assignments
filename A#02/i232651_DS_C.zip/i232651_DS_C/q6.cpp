// Assignment # 02
// Muhammad Azmat
// 23I-2651
// DS-C

#include <iostream>
#include <string>

using namespace std;

void star_printing_board(int dimension, char style, int count1 = 0, int count2 = 0);
void space_printing_board(int dimension, char style, int count1 = 0, int count2 = 0);
void printing1(int sizee_1, char smbol, int count1 = 0); // prints *
void printing2(int sizee_1, char smbol, int count1 = 0); // prints ^
void column_recursion(int sizee_1, char smbol, int count1 = 0);
void row_recursion(int sizee_1, char smbol, int count1 = 0);
void times_print(int sizee, char symbol, int count1 = 0, int count2 = 0);

int main()
{
    int chess = 0;
    int count = 0;
    char signn = '*';

    // input validation
    do
    {
        cout << "** WELCOME TO CHESS **" << endl;
        cout << "Enter the size of the board you want to make" << endl;
        cin >> chess;

    } while (chess < 6 || chess % 2 != 0);

    times_print(chess, signn);

    return 0;
}

void star_printing_board(int dimension, char style, int count1, int count2)
{
    int dim_2 = dimension - 1;
    // matlb he chale ga 3 dfa when entered 6
    if (count1 >= dimension / 2 && count2 >= dim_2 / 2)
    {
        return;
    }

    else
    {
        printing1(dimension, style, 0);
        printing2(dim_2, style, 0);
        star_printing_board(dimension, style, count1 + 1, count2 + 1);
    }
}

void space_printing_board(int dimension, char style, int count1, int count2)
{
    int dim_2 = dimension - 1;
    // matlb he chale ga 3 dfa when entered 6
    if (count1 >= dimension / 2 && count2 >= dim_2 / 2)
    {
        return;
    }

    else
    {
        printing2(dim_2, style, 0);
        printing1(dimension, style, 0);
        space_printing_board(dimension, style, count1 + 1, count2 + 1);
    }
}

void printing1(int sizee_1, char smbol, int count1)
{
    // yeh chalega 6 dfa when entered 6
    if (count1 == sizee_1)
    {
        return;
    }
    else
    {
        cout << smbol << " ";
        printing1(sizee_1, smbol, count1 + 1);
    }
}

void printing2(int sizee_1, char smbol, int count1)
{
    // yeh chalega 4 dfa

    smbol = ' ';
    if (count1 >= sizee_1)
    {
        return;
    }
    else
    {
        cout << smbol << " ";
        printing2(sizee_1, smbol, count1 + 1);
    }
}

void column_recursion(int sizee_1, char smbol, int count1)
{
    if (count1 >= sizee_1)
    {
        return;
    }
    else
    {
        star_printing_board(sizee_1, smbol, 0);
        cout << '*';
        cout << endl;
        column_recursion(sizee_1, smbol, count1 + 1);
    }
}

void row_recursion(int sizee_1, char smbol, int count1)
{
    if (count1 >= sizee_1)
    {
        return;
    }
    else
    {
        space_printing_board(sizee_1, smbol, 0);
        cout << '*';
        cout << endl;
        row_recursion(sizee_1, smbol, count1 + 1);
    }
}

void times_print(int sizee, char symbol, int count1, int count2)
{
    if (count1 >= sizee / 2 && count2 >= sizee / 2)
    {
        return;
    }
    else
    {
        column_recursion(sizee, symbol);
        row_recursion(sizee, symbol);
        times_print(sizee, symbol, count1 + 1, count2 + 1);
    }
}
