// MUHAMMAD AZMAT
// OOP PROJECT
// 23I-2651
// DS-C

#ifndef CENTIPEDE_CPP_
#define CENTIPEDE_CPP_
#include "util.h"
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <cmath>
#include <ctime>
using namespace std;

// Bottom-left corner: (0, 0)
// Bottom-right corner: (1019, 0)
// Top-left corner: (0, 839)
// Top-right corner: (1019, 839)

class score // making a class for file handling
{
protected:
	int scoree;
	int high_score;
	bool hs_triggerer = false; // when user presses h on keyboard, this bool var will become true, and I'm using its setter in printable keys function and getter in gamedisplay function, and accessing via game bb variable.

public:
	score()
	{
		scoree = 0;
		ifstream input("bb_high_score.txt"); // high score bb_high_score se input krwao
		input >> high_score;
	}

	void set_score(int scora)
	{
		scoree = scora;
		return;
	}

	int &get_score()
	{
		return scoree;
	}

	int &get_high_score()
	{
		return high_score;
	}

	void show_score()
	{
		stringstream score_board;
		score_board << "Your Score: " << scoree;
		string scoreStr = score_board.str();
		DrawString(9, 15, scoreStr.c_str(), colors[WHITE]);
	}

	bool set_trigger(bool t)
	{
		hs_triggerer = t;
	}

	bool get_trigger()
	{
		return hs_triggerer;
	}

	void show_high_score()
	{
		if (scoree > high_score)
		{
			high_score = scoree;
		}

		stringstream hs;
		hs << " High Score: " << high_score;
		string highscoreStr = hs.str();

		ofstream output("bb_high_score.txt");
		if (output.is_open())
		{
			output << high_score;
			output.close();
		}

		DrawString(405, 250, highscoreStr.c_str(), colors[WHITE]);
	}
};

class bricks : public score
{
protected:
	int x = 0;
	int y = 790;
	int square_size = 50;
	static const int brick_rows = 5;
	static const int brick_cols = 20;
	// making a 2d array
	int brick_arr[brick_rows][brick_cols];
	bool brick_show[brick_rows][brick_cols];
	// score hamara_score;
	// int hamaraa_score;

public:
	bricks()
	{
		for (int i = 0; i < brick_rows; ++i)
		{
			for (int j = 0; j < brick_cols; ++j)
			{
				brick_arr[i][j] = 0; // default value 0 rkhi hai
				brick_show[i][j] = true;
			}
		}
	}

	int get_bricks_x()
	{
		return x;
	}

	int get_bricks_y()
	{
		return y;
	}

	bool get_brick_showing(int row, int col)
	{
		return brick_show[row][col];
	}

	// void show_score() {

	// }

	score &get_hamara_score()
	{
		// return hamara_score;
	}

	int get_bricks_size()
	{
		return square_size;
	}

	int get_brick_rows()
	{
		return brick_rows;
	}

	int get_brick_cols()
	{
		return brick_cols;
	}

	int get_brick_arr(int row, int col)
	{
		return brick_arr[row][col];
	}

	void set_brick_arr(int row, int col, int val)
	{
		brick_arr[row][col] = val;
	}

	void draw_bricks()
	{
		srand(time(0));
		int Colors[5] = {45, 75, 125, 17, 68}; // color codes of teal, white, purple and golden

		int brick_width = get_bricks_size(); // bricks are square, so width = height
		int brick_height = get_bricks_size();

		for (int row = 0; row < brick_rows; row++)
		{
			for (int cols = 0; cols < brick_cols; cols++)
			{
				int brick_x = cols * (brick_width + 2);
				int brick_y = y - row * (brick_height + 2);
				if (brick_arr[row][cols] == 0)
				{
					DrawSquare(brick_x, brick_y, brick_width, colors[Colors[rand() % 5]]);
				}
				if (row == 1 && (brick_arr[row][cols] == 0))
					DrawSquare(brick_x, brick_y, brick_width, colors[Colors[rand() % 5]]);
				if (row == 2 && (brick_arr[row][cols] == 0))
					DrawSquare(brick_x, brick_y, brick_width, colors[Colors[rand() % 5]]);
				if (row == 3 && (brick_arr[row][cols] == 0))
					DrawSquare(brick_x, brick_y, brick_width, colors[Colors[rand() % 5]]);
				if (row == 4 && (brick_arr[row][cols] == 0))
					DrawSquare(brick_x, brick_y, brick_width, colors[Colors[rand() % 5]]);
			}
		}
	}
	bool collision(int ball_x, int ball_y, int ball_size, score &myscore)
	{
		int brick_width = get_bricks_size();
		int brick_height = get_bricks_size();
		bool collided = false;
		int pwr_fruit_bricks = 45;

		for (int rows = 0; rows < brick_rows; rows++)
		{
			for (int cols = 0; cols < brick_cols; cols++)
			{
				// using formula we used before
				if (brick_arr[rows][cols] != -1 && brick_show[rows][cols]) // putting this condition to make sure that the ball doesnot bounce back from the same brick which now disappears
				{
					int brick_x = cols * (brick_width + 2);
					int brick_y = y - rows * (brick_height + 2);

					// checking for collision with every single brick
					if (ball_x + ball_size >= brick_x && ball_x <= brick_x + brick_width &&
						ball_y + ball_size >= brick_y && ball_y <= brick_y + brick_height)
					{
						brick_arr[rows][cols] = -1;
						cout << brick_arr[rows][cols] << endl;
						cout << "(" << rows << "," << cols << ")" << endl;
						// hamara_score.set_score(hamara_score.get_score() + 5);

						myscore.set_score(myscore.get_score() + 5);
						collided = true;
					}
				}
			}
		}
		return collided;
	}
};

class bricks2 : public score // this class is for level 2 of bb game
{
protected:
	int x1 = 0;
	int y1 = 790;
	int square_size = 30;
	static const int brick_rows = 20;
	static const int brick_cols = 15;
	// making a 2d array
	int brick_arr[brick_rows][brick_cols];
	bool brick_show[brick_rows][brick_cols];
	// score hamara_score;
	// int hamaraa_score;

public:
	bricks2()
	{
		for (int i = 0; i < brick_rows; ++i)
		{
			for (int j = 0; j < brick_cols; ++j)
			{
				brick_arr[i][j] = 0; // default value 0 rkhi hai
				brick_show[i][j] = true;
			}
		}
	}

	int get_bricks_x()
	{
		return x1;
	}

	int get_bricks_y()
	{
		return y1;
	}

	bool get_brick_showing(int row, int col)
	{
		return brick_show[row][col];
	}

	// void show_score() {

	// }

	score &get_hamara_score()
	{
		// return hamara_score;
	}

	int get_bricks_size()
	{
		return square_size;
	}

	int get_brick_rows()
	{
		return brick_rows;
	}

	int get_brick_cols()
	{
		return brick_cols;
	}

	int get_brick_arr(int row, int col)
	{
		return brick_arr[row][col];
	}

	void set_brick_arr(int row, int col, int val)
	{
		brick_arr[row][col] = val;
	}

	void draw_bricks2()
	{
		srand(time(0));
		int Colors[5] = {45, 75, 125, 17, 68}; // color codes of teal, white, purple and golden

		int brick_width = get_bricks_size(); // bricks are square, so width = height
		int brick_height = get_bricks_size();

		for (int row = 0; row < brick_rows; row++)
		{
			for (int cols = 0; cols < brick_cols; cols++)
			{
				if ((row <= 3 && cols <= 4) || ((row > 3 && row <= 7) && (cols > 4 && cols <= 9)) || ((row > 7 && row <= 11) && (cols > 9 && cols <= 14)) || ((row > 11 && row <= 15) && (cols > 4 && cols <= 9)) || ((row > 15 && row <= 20) && cols <= 4))
				{
					int brick_x1 = cols * (brick_width + 2);
					int brick_y1 = y1 - row * (brick_height + 2);
					if (brick_arr[row][cols] == 0 && brick_show[row][cols])
					{
						DrawSquare(brick_x1, brick_y1, brick_width, colors[Colors[rand() % 5]]);
					}
					if (row == 1 && (brick_arr[row][cols] == 0))
						DrawSquare(brick_x1, brick_y1, brick_width, colors[Colors[rand() % 5]]);
					if (row == 2 && (brick_arr[row][cols] == 0))
						DrawSquare(brick_x1, brick_y1, brick_width, colors[Colors[rand() % 5]]);
					if (row == 3 && (brick_arr[row][cols] == 0))
						DrawSquare(brick_x1, brick_y1, brick_width, colors[Colors[rand() % 5]]);
					if (row == 4 && (brick_arr[row][cols] == 0))
						DrawSquare(brick_x1, brick_y1, brick_width, colors[Colors[rand() % 5]]);
				}
				else
				{
					brick_show[row][cols] = false;
				}
			}
		}
	}
	bool collision2(int ball_x, int ball_y, int ball_size, score &myscore)
	{
		int brick_width = get_bricks_size();
		int brick_height = get_bricks_size();
		bool collided = false;
		int pwr_fruit_bricks = 45;

		for (int rows = 0; rows < brick_rows; rows++)
		{
			for (int cols = 0; cols < brick_cols; cols++)
			{
				if ((rows <= 3 && cols <= 4) || ((rows > 3 && rows <= 7) && (cols > 4 && cols <= 9)) || ((rows > 7 && rows <= 11) && (cols > 9 && cols <= 14)) || ((rows > 11 && rows <= 15) && (cols > 4 && cols <= 9)) || ((rows > 15 && rows <= 20) && cols <= 4))
				{
					// using formula we used before
					if (brick_arr[rows][cols] != -1 && brick_show[rows][cols]) // putting this condition to make sure that the ball doesnot bounce back from the same brick which now disappears
					{
						int brick_x1 = cols * (brick_width + 2);
						int brick_y1 = y1 - rows * (brick_height + 2);

						// checking for collision with every single brick
						if (ball_x + ball_size >= brick_x1 && ball_x <= brick_x1 + brick_width &&
							ball_y + ball_size >= brick_y1 && ball_y <= brick_y1 + brick_height)
						{
							brick_arr[rows][cols] = -1;
							cout << brick_arr[rows][cols] << endl;
							cout << "(" << rows << "," << cols << ")" << endl;
							// hamara_score.set_score(hamara_score.get_score() + 5);

							myscore.set_score(myscore.get_score() + 5);
							collided = true;
						}
					}
				}
			}
		}
		return collided;
	}
};

class slider
{
protected:
	int x1 = 500;
	int y1 = 150;
	int x2 = 70;
	int y2 = 15;
	int sliderr[4]{x1, y1, x2, y2}; // storing all 4 dimensions in a 1D Array
	int slider_color = 123;			// ASCII of floral white color

public:
	int get_sliderr_x1()
	{
		return sliderr[0];
	}

	int get_sliderr_y1()
	{
		return sliderr[1];
	}

	int &set_slider_color(int a)
	{
		slider_color = a;
	}

	int get_sliderr_x2()
	{
		return sliderr[2];
	}

	int get_sliderr_y2()
	{
		return sliderr[3];
	}

	int get_slider_width()
	{
		return x2;
	}

	void set_slider_pos(int x)
	{
		sliderr[0] = x;
	}

	void draw()
	{
		DrawRoundRect(get_sliderr_x1(), get_sliderr_y1(), get_sliderr_x2(), get_sliderr_y2(), colors[slider_color]);
	}
};

class ball : public bricks, public bricks2, public slider
{
protected:
	int x = 500;
	int y = 450;
	int ball_size = 10;
	int differ_x = 7;
	int differ_y = 7;
	slider myslider;
	bool slider_fusing = false;
	bricks mybricks;
	bricks2 mybricks2;
	int life_count = 3;
	int ball_color = 123;
	int level; // ASCII value of floral white

public:
	int get_x()
	{
		return x;
	}

	int get_y()
	{
		return y;
	}

	int get_size()
	{
		return ball_size;
	}

	int get_change_x()
	{
		return get_x() + differ_x;
	}

	slider &getSlider()
	{
		return myslider;
	}

	bool is_slider_fusing()
	{
		return slider_fusing;
	}

	bricks &getbricks()
	{
		return mybricks;
	}

	bricks2 &getbricks2()
	{
		return mybricks2;
	}

	int &get_life_count()
	{
		return this->life_count;
	}

	int get_change_y()
	{
		return get_y() - differ_y;
	}

	void moving_ball(score &myScore)
	{
		x += differ_x;
		y += differ_y;

		if (x >= 1019 || x <= 0) // using or gate and specifying the corner dimensions of x axis
		{
			differ_x = differ_x * (-1);
		}

		if (y >= 839) // using or gate and specifying the corner dimensions of y axis
		{
			differ_y = differ_y * (-1);
		}

		if (y <= 0)
		{
			// exit(0); // testing case
			differ_y = differ_y * (-1);
			life_count--;
			x = 500;
			y = 450;
			differ_x = 6;
			differ_y = 6;
			if (life_count == 0)
			{
				cout << "** GAME OVER ** " << endl;
			}
		}

		if (x >= myslider.get_sliderr_x1() && x <= myslider.get_sliderr_x1() + myslider.get_sliderr_x2() && y >= myslider.get_sliderr_y1() && y <= myslider.get_sliderr_y1() + myslider.get_sliderr_y2())
		{
			// cout<<"Ball X: "<<x<<" Ball y: "<<y<<endl<<endl; // testing case
			differ_y = differ_y * (-1); // changing the direction of slider when colliding with bricks
			slider_fusing = true;
			myslider.set_slider_color(ball_color);
		}

		if (level == 1)
		{
			if (mybricks.collision(x, y, ball_size, myScore)) // for level 1
			{
				differ_y = differ_y * (-1);
				ball_color = rand() % 100;
			}
		}
		else
		{
			if (mybricks2.collision2(x, y, ball_size, myScore)) // for level 2
			{
				differ_y = differ_y * (-1);
				ball_color = rand() % 100;
			}
		}
	}
	void set_level(int lev)
	{
		level = lev;
	}

	void draw()
	{
		DrawCircle(get_x(), get_y(), get_size(), colors[ball_color]);
	}
};

class pwr_fruit : public bricks, public bricks2
{
private:
	int xx;
	int yy;
	int ssize;

public:
	int get_xx()
	{
		return xx;
	}

	int get_yy()
	{
		return yy;
	}

	int get_ssize()
	{
		return ssize;
	}

	void draw()
	{
		DrawCircle(get_xx(), get_yy(), get_ssize(), colors[FLORAL_WHITE]);
	}
};

class menu
{
protected:
	bool menuu = true;
	bool lvl1_check = false;
	bool lvl2_check = false;

public:
	bool set_menu_status(bool set)
	{
		menuu = set;
	}

	bool get_menu_status()
	{
		return menuu;
	}

	bool set_lvl1_status(bool set)
	{
		lvl1_check = set;
	}

	bool get_lvl_1_status()
	{
		return lvl1_check;
	}

	bool set_lvl2_status(bool set)
	{
		lvl2_check = set;
	}

	bool get_lvl_2_status()
	{
		return lvl2_check;
	}

	void draw_bg()
	{
		DrawSquare(0, 0, 2000, colors[BLUE]);
	}

	void level_1()
	{
		DrawString(450, 450, "Level 1", colors[WHITE]);
	}

	void level_2()
	{
		DrawString(450, 400, "Level 2", colors[WHITE]);
	}

	void end_bb()
	{
		DrawString(435, 300, "End Game", colors[WHITE]);
	}

	void show_hs()
	{
		DrawString(435, 350, "High Score", colors[WHITE]);
	}
};

class game : public ball, public pwr_fruit, public menu
{
private:
	slider myslider;
	bricks mybricks;
	bricks2 mybricks2;
	ball myball;
	score myscore;
	pwr_fruit mypwrfruit;
	menu mymenu;

public:
	slider &getSlider()
	{
		return myslider;
	}
	bricks &getbricks()
	{
		return mybricks;
	}
	bricks2 &getbricks2()
	{
		return mybricks2;
	}
	ball &getball()
	{
		return myball;
	}
	score &getscore()
	{
		return myscore;
	}
	pwr_fruit &getmypwrfruit()
	{
		return mypwrfruit;
	}
	void move_ball()
	{
		myball.moving_ball(myscore);
	}

	menu &getmymenu()
	{
		return mymenu;
	}
	ball set_level(int lvl)
	{
		myball.set_level(lvl);
	}
};

/* Function sets canvas size (drawing area) in pixels...
 *  that is what dimensions (x and y) your game will have
 *  Note that the bottom-left coordinate has value (0,0) and top-right coordinate has value (width-1,height-1)
 **/

void SetCanvasSize(int width, int height)
{
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0, width, 0, height, -1, 1); // set the screen size to given width and height.
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

game bb;
void GameDisplay()
{

	if (bb.getmymenu().get_menu_status() == true)
	{

		bb.get_menu_status();
		bb.draw_bg();
		bb.level_1();
		bb.level_2();
		bb.show_hs();
		bb.end_bb();

		if (bb.getscore().get_trigger() == true) // when in menu, only then you have option to see highscore
		{
			bb.getscore().show_high_score();
		}
	}
	else
	{

		if (bb.getmymenu().get_menu_status() == false && bb.getmymenu().get_lvl_1_status() == true)
		{
			glClearColor(0.0, 0.0, 0.0, 0.0);
			glClear(GL_COLOR_BUFFER_BIT);

			bb.getbricks().draw_bricks();
			bb.getball().getSlider().draw();
			bb.getball().draw();

			stringstream lives;
			lives << "Lives: " << bb.getball().get_life_count();
			string livesStr = lives.str();
			DrawString(920, 50, livesStr.c_str(), colors[RED]);

			DrawString(920, 15, "23i-2651", colors[WHITE]);

			bb.getscore().show_score();

			if (bb.getball().get_life_count() <= 0)
			{
				DrawString(400, 400, "Game Over Gamer", colors[RED]);
				glutIdleFunc(NULL);
			}
		}
		else
		{
			if (bb.getmymenu().get_menu_status() == false && bb.getmymenu().get_lvl_2_status() == true)
			{
				glClearColor(0.0, 0.0, 0.0, 0.0);
				glClear(GL_COLOR_BUFFER_BIT);

				bb.getbricks2().draw_bricks2();
				bb.getball().getSlider().draw();
				bb.getball().draw();

				stringstream lives;
				lives << "Lives: " << bb.getball().get_life_count();
				string livesStr = lives.str();
				DrawString(920, 50, livesStr.c_str(), colors[RED]);

				DrawString(920, 15, "23i-2651", colors[WHITE]);

				bb.getscore().show_score();

				if (bb.getball().get_life_count() <= 0)
				{
					DrawString(400, 400, "Game Over Gamer", colors[RED]);
					glutIdleFunc(NULL);
				}
			}
		}
	}

	glutSwapBuffers();
}

/*
 * This function has three argument variable key contains the ASCII of the key pressed, while x and y tells the
 * program coordinates of mouse pointer when key was pressed.
 * */

void NonPrintableKeys(int key, int x, int y)
{
	if (key == GLUT_KEY_LEFT)
	{
	}
	else if (key == GLUT_KEY_RIGHT)
	{
		// dx++;
	}
	else if (key == GLUT_KEY_UP)
	{
	}

	else if (key == GLUT_KEY_DOWN)
	{
	}

	/* This function calls the Display function to redo the drawing. Whenever you need to redraw just call
	 * this function*/

	glutPostRedisplay();
}

/*This function is called (automatically) whenever any printable key (such as x,b, enter, etc.)
 * is pressed from the keyboard
 * This function has three argument variable key contains the ASCII of the key pressed, while x and y tells the
 * program coordinates of mouse pointer when key was pressed.
 * */
void PrintableKeys(unsigned char key, int x, int y)
{
	if (key == 27)
	{
		exit(1); // 27 is ASCII for esc
	}

	if (key == 'b' || key == 'B') // Key for placing the bomb
	{
		// do something if b is pressed
		cout << "b pressed" << endl;
	}
	if (key == 109) // 109 is ASCII for m
	{
		bb.getmymenu().set_menu_status(false);
		bb.getmymenu().set_lvl1_status(true);
		bb.set_level(1);
		bb.getmymenu().set_lvl2_status(false);
	}

	if (key == 115) // 115 is ASCII for s
	{
		bb.getmymenu().set_menu_status(false);
		bb.getmymenu().set_lvl2_status(true);
		bb.set_level(2);
		bb.getmymenu().set_lvl1_status(false);
	}

	if (key == 104) // 104 is ASCII for h
	{
		bb.getscore().set_trigger(true);
	}

	if (key == 32) // 32 is ASCII for space bar
	{
		bb.getmymenu().set_menu_status(true);
	}

	glutPostRedisplay();
}

void Timer(int m)
{

	if (bb.getmymenu().get_menu_status() == false && bb.getmymenu().get_lvl_1_status() == true) // this condition is for, when we're in menu, in the background game na chaley. // this condition is for, when we're in menu, in the background game na chaley.
	{
		if (bb.getball().get_life_count() > 0)
		{
			bb.getbricks().collision(bb.getball().get_x(), bb.getball().get_y(), bb.getball().get_size(), bb.getscore());
			bb.move_ball();
		}
	}

	if (bb.getmymenu().get_menu_status() == false && bb.getmymenu().get_lvl_2_status() == true) // this condition is for, when we're in menu, in the background game na chaley.
	{
		if (bb.getball().get_life_count() > 0)
		{
			bb.getbricks2().collision2(bb.getball().get_x(), bb.getball().get_y(), bb.getball().get_size(), bb.getscore());
			bb.move_ball();
		}
	}

	glutPostRedisplay();
	glutTimerFunc(1000.0 / 60, Timer, 0);
}

/*This function is called (automatically) whenever your mouse moves witin inside the game window
 *
 * You will have to add the necessary code here for finding the direction of shooting
 *
 * This function has two arguments: x & y that tells the coordinate of current position of move mouse
 *
 * */
void MousePressedAndMoved(int x, int y)
{
	cout << x << " " << y << endl;
	glutPostRedisplay();
}
void MouseMoved(int x, int y)
{
	// myball.getSlider().set_slider_pos(x);
	bb.getball().getSlider().set_slider_pos(x);
	glutPostRedisplay();
}

/*This function is called (automatically) whenever your mouse button is clicked witin inside the game window
 *
 * You will have to add the necessary code here for shooting, etc.
 *
 * This function has four arguments: button (Left, Middle or Right), state (button is pressed or released),
 * x & y that tells the coordinate of current position of move mouse
 *
 * */
void MouseClicked(int button, int state, int x, int y)
{

	if (button == GLUT_LEFT_BUTTON) // dealing only with left button
	{
		cout << GLUT_DOWN << " " << GLUT_UP << endl;
	}
	else if (button == GLUT_RIGHT_BUTTON) // dealing with right button
	{
		cout << "Right Button Pressed" << endl;
	}
	glutPostRedisplay();
}

// main function
int main(int argc, char *argv[])
{

	int width = 1020, height = 840; // i have set my window size to be 800 x 600

	InitRandomizer();							  // seed the random number generator...
	glutInit(&argc, argv);						  // initialize the graphics library...
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA); // we will be using color display mode
	glutInitWindowPosition(50, 50);				  // set the initial position of our window
	glutInitWindowSize(width, height);			  // set the size of our window
	glutCreateWindow("OOP Project");			  // set the title of our game window
	SetCanvasSize(width, height);				  // set the number of pixels...

	// Register your functions to the library,
	// you are telling the library names of function to call for different tasks.
	// glutDisplayFunc(display); // tell library which function to call for drawing Canvas.

	glutDisplayFunc(GameDisplay); // tell library which function to call for drawing Canvas.
	glutSpecialFunc(NonPrintableKeys);
	glutKeyboardFunc(PrintableKeys);
	glutTimerFunc(1000.0, Timer, 0);

	glutMouseFunc(MouseClicked);
	glutPassiveMotionFunc(MouseMoved);
	glutMotionFunc(MousePressedAndMoved);

	glutMainLoop();
	return 1;
}
#endif
