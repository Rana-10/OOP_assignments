// Muhammad Azmat
// 23i-2651
// DS-C

#include <iostream>
#include <string>
#include <ctime>

using namespace std;

int main()
{
    srand(time(0));
    int rows;
    int cols;

    cout << "** WELCOME TO THE PROGRAM ** " << endl;
    cout << "Enter the number of rows " << endl;
    cin >> rows;
    cout << "Enter the number of columns " << endl;
    cin >> cols;

    int tot_ele = rows * cols;

    cout << endl;

    int **array = new int *[rows];

    // populating our 2D Array

    for (int i = 0; i < rows; i++)
    {
        array[i] = new int[cols];
        for (int j = 0; j < cols; j++)
        {
            array[i][j] = rand() % 10;
        }
    }

    // printing our Array

    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++)
        {
            cout << array[i][j] << " ";
        }
        cout << endl;
    }

    cout << endl;

    cout << "The size of the array is " << tot_ele << endl;

    cout << endl;

    int row_index;
    int col_index;
    int flag = 0;

 // if user enters an invalid index, ask them again until they enter correct value
    while (true)
    {
        cout << "Enter the indexes of number you want to find " << endl;
        cout << endl;
        cout << "Enter the index number for row " << endl;
        cin >> row_index;
        cout << "Enter the index number for column " << endl;
        cin >> col_index;
        if (row_index > 0 && col_index > 0 && row_index < rows && col_index < cols)
            break;
        else
            cout << " ** Invalid Index ** " << endl;
    }
    cout << endl;

    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++)
        {
            if (array[i][j] == array[row_index][col_index])
            {
                cout << "The number at this index is " << array[i][j] << endl;
                flag = 1;
                break;
            }
        }
        if (flag == 1)
            break;
    }

    cout << endl;


    // resizing the array

    int r_2;
    int c_2;

    cout << "let's resize your array! " << endl;
    cout << endl;
    cout << "enter the number of rows you want to switch to " << endl;
    cin >> r_2;
    cout << "enter the number of columns you want to switch to " << endl;
    cin >> c_2;

    int **array_2 = new int *[r_2];
    for (int i = 0; i < r_2; i++)
    {
        array_2[i] = new int[c_2];
        for (int j = 0; j < c_2; j++)
        {
            if (i < rows && j < cols)
                array_2[i][j] = array[i][j];
            else
                array_2[i][j] = 0; // printing 0 if resized array is bigger than original array and thus some spaces are left free.
        }
    }

    for (int i = 0; i < r_2; i++)
    {
        for (int j = 0; j < c_2; j++)
        {
            cout << array_2[i][j] << " ";
        }
        cout << endl;
    }

    cout << endl;

    // for deallocating the original array

    for (int i = 0; i < rows; i++)
    {
        delete[] array[i];
    }

    delete[] array;

    // for deallocating the resized array

    for (int i = 0; i < r_2; i++)
    {
        delete[] array_2[i];
    }

    delete[] array_2;
}
