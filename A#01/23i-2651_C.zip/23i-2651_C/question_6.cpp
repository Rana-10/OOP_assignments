// Muhammad Azmat
// 23i-2651
// DS-C

#include <iostream>
using namespace std;

void display_matrix(char **arr, int x, int y, char symbol);
void encryption(char **arr, int x, int y, char symbol);
void decryption(char **arr, int x, int y, char symbol);
void display_specific_matrix(char **arr, int x, int y, char symbol);

int main()
{

    cout << "** WELCOME TO THE PROGRAM ** " << endl;
    cout << "Please enter the symbol you'd like to draw a pattern with " << endl;
    char sym;
    cin >> sym;

    cout << endl;

    int m = 5;
    int n = 5;

    char **array = new char *[m];
    for (int i = 0; i < m; i++)
    {
        array[i] = new char[n];
    }

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            array[i][j] = ' ';
        }
        cout << endl;
    }

    display_matrix(array, m, n, sym);

    cout << endl;
    encryption(array, m, n, sym);
    cout << endl;
    // the decryption function is called in encrypted function

    display_specific_matrix(array, m, n, sym);

    // deallocating the original array
    for (int i = 0; i < m; i++)
    {
        delete[] array[i];
    }
    delete[] array;

    return 0;
}

void display_matrix(char **arr, int x, int y, char symbol)
{
    for (int i = 0; i < x; i++)
    {
        for (int j = 0; j < y; j++)
        {
            arr[i][j] = symbol;
            if (i == 0 || i == 2)
                cout << arr[i][j] << " ";
            if (i == 1 || i == 3 || i == 4)
            {
                cout << arr[i][j];
                break;
            }
        }
        cout << endl;
    }
}

void encryption(char **arr, int x, int y, char symbol)
{
    char **transpose_arr = new char *[x];
    for (int i = 0; i < x; i++)
    {
        transpose_arr[i] = new char[y];
    }
    for (int i = 0; i < x; i++)
    {
        for (int j = 0; j < y; j++)
        {
            transpose_arr[i][j] = ' ';
        }
    }

    // taking transpose and then doing row swap to get encrypted form
    for (int i = 0; i < x; i++)
    {
        for (int j = 0; j < y; j++)
        {
            transpose_arr[i][j] = arr[j][i];
            char temp = ' ';
            temp = transpose_arr[0][j];
            transpose_arr[0][j] = transpose_arr[4][j];
            transpose_arr[4][j] = temp;
        }
    }

    for (int i = 0; i < x; i++)
    {
        for (int j = 0; j < y; j++)
        {

            cout << transpose_arr[i][j] << " ";
        }
        cout << endl;
    }
    cout << endl;
    decryption(transpose_arr, x, y, symbol);

    for (int i = 0; i < x; i++)
    {
        delete[] transpose_arr[i];
    }
    delete[] transpose_arr;
}

void decryption(char **arr, int x, int y, char symbol)
{
    for (int i = 0; i < x; i++)
    {
        for (int j = 0; j < y; j++)
        {
            arr[i][j] = symbol;
            if (i == 0 || i == 2)
                cout << arr[i][j] << " ";
            if (i == 1 || i == 3 || i == 4)
            {
                cout << arr[i][j];
                break;
            }
        }
        cout << endl;
    }
}

void display_specific_matrix(char **arr, int x, int y, char symbol)
{
    char sym2;
    int index_r;
    int index_c;

    while (true)
    {
        cout << "Please enter the symbol followed by the specific index you want the change to happen " << endl;
        cin >> sym2;
        cin >> index_r >> index_c;
        if ((index_r >= 0) && (index_r < x) && (index_c >= 0) && (index_c < y))
        {
            break;
        }
    }

    for (int i = 0; i < x; i++)
    {
        for (int j = 0; j < y; j++)
        {

            if (i == 0 || i == 2)
            {
                if (arr[i][j] != arr[index_r][index_c])
                {
                    cout << arr[i][j] << " ";
                }

                if (arr[i][j] == arr[index_r][index_c])
                {
                    arr[index_r][index_c] = sym2;
                    cout << arr[i][j] << " ";
                }
            }
            if (i == 1 || i == 3 || i == 4)
            {
                cout << arr[i][j];
                break;
            }
        }
        cout << endl;
    }
}
