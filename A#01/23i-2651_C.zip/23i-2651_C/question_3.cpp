// Muhammad Azmat
// 23i-2651
// DS-C

#include <iostream>
#include <string>
#include <ctime>

using namespace std;

string look_n_say_seq(string next_num);

int main()
{
    int number;
    long long int range;
    bool overflow = false;

    // taking valid input from user and if number and range is invalid, asking again

    while (true)
    {
        cout << "** WELCOME TO PROGRAM ** " << endl;
        cout << "Enter the starting number" << endl;
        cin >> number;
        cout << "Enter range of numbers " << endl;
        cin >> range;
        if (number > 0 && range > 0)
            break;
    }

    cout << endl;

    // making the look and say program using string
    string seq[range];
    seq[0] = to_string(number);
    // to_string is a function which converts the int (numerical) value into string.

    for (int i = 1; i < range; i++)
    {
        string next_term;
        next_term = look_n_say_seq(seq[i - 1]);
        if (next_term.size() > 19)
        {
            overflow = true;
            cout << "** OVERFLOW HAS OCCURRED ** " << endl;
            break;
        }
        seq[i] = next_term;
    }

    cout << endl;

    cout << " The required pattern will be " << endl;
    // printing the output
    for (int a = 0; a < range; a++)
    {
        cout << seq[a];
        cout << endl;
    }

    return 0;
}

string look_n_say_seq(string num)
{
    string abc = "";
    int flag = 1;

    for (int i = 0; i < num.length(); i++)
    {
        if (i + 1 < num.length() && num[i] == num[i + 1])
            flag++;
        else
        {
            abc += to_string(flag) + num[i];
            flag = 1;
        }
    }
    return abc;
}