// Muhammad Azmat
// 23i-2651
// DS-C

#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main()
{
    cout << " ** WELCOME TO THE PROGRAM ** " << endl;

    char array[10][10];

    // reading the data from boggle.txt i.e. using file handling

    ifstream in("boggle.txt");
    for (int i = 0; i < 10; i++)
    {
        for (int j = 0; j < 10; j++)
        {
            in >> array[i][j];
            cout << array[i][j];
        }
        cout << endl;
    }

    cout << endl;

    string prompt;
    cout << "Enter the word you found " << endl;
    cin >> prompt;

    // making a char array, so we can convert user's input from string to char array, so we can compare

    char *prompt_arr = new char[prompt.length() + 1];

    for (int i = 0; i < prompt.length(); i++)
    {
        prompt_arr[i] = prompt[i];
        // cout << prompt_arr[i];
    }
    cout << endl;

    int count = 0;

    for (int i = 0; i < 10 && count < prompt.length(); i++)
    {
        for (int j = 0; j < 10 && count < prompt.length(); j++)
        {
            if (array[i][j] == prompt[count])
            {
                count++;
            }
        }
    }

    // to check when count == prompt.length, show word matches.

    // cout << count << endl;
    // cout << prompt.length() << endl;

    if (count == prompt.length())
        cout << "WORD FOUND ";
    else
        cout << "WORD NOT FOUND! ";

    return 0;
}
