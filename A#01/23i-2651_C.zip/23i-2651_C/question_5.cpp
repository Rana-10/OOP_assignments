// Muhammad Azmat
// 23i-2651
// DS-C

#include <iostream>
#include <string>

using namespace std;

int length(const string &len);
void concatenate(string conc, string l);

int main()
{
    string input;
    string pattern;
    cout << "** WELCOME TO PROGRAM ** " << endl;
    cout << "Enter the words bro" << endl;
    cin >> input;
    cout << "Enter the pattern" << endl;
    cin >> pattern;

    // making char arrays.
    const int size = 50;
    char input_arr[input.length()];
    char pattern_arr[pattern.length()];

    // storing the data in char arrays.
    for (int i = 0; i < input.length(); i++)
    {
        input_arr[i] = input[i];
    }

    for (int i = 0; i < pattern.length(); i++)
    {
        pattern_arr[i] = pattern[i];
    }

    int c = length(pattern_arr);
    cout << "The number of words are " << c << endl;
    // concatenate(pattern_arr, input);

    return 0;
}

int length(const string &len)
{
    return len.length();
}

void concatenate(string conc, string l)
{
    int inp = stoi(l);

    int size;
    cout << "Enter the second array's size if you want to concatenate" << endl;
    char array_2[size];

    char conc_array[inp + size];

    int i, j, k = 0;
    while (i < inp && j < size)
    {
        if (conc[i] < array_2[j])
        {
            conc_array[k] = conc[i];
            i++;
            k++;
        }
        else
        {
            conc_array[k] = array_2[j];
            j++;
            k++;
        }
    }
    while (i < inp)
        conc_array[k++] = conc[i++];
    while (j < size)
        conc_array[k++] = array_2[j++];
}