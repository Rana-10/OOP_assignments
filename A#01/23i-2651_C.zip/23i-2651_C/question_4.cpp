// Muhammad Azmat
// 23i-2651
// DS-C

#include <iostream>
#include <string>
#include <ctime>

using namespace std;

void scalar_val(int ***arr, int m, int n, int p);
void transpose(int ***arr, int m, int n, int p);
void deallocation(int ***arr, int m, int n, int p);

int main()
{
    srand(time(0));

    int min_val = 10;
    int max_val = 99;
    int m, n, p;
    cout << "Enter 3 values to give to the 3D Array " << endl;
    cin >> m >> n >> p;

    int ***arr = new int **[m]; // code for creating a 3D Array
    for (int i = 0; i < m; i++)
    {
        arr[i] = new int *[n];
        for (int j = 0; j < n; j++)
        {
            arr[i][j] = new int[p];
            for (int k = 0; k < p; k++)
            {
                arr[i][j][k] = min_val + rand() % (max_val - min_val + 1); // filling the array with random values from 10 till 99
            }
        }
    }

    // till here we have created 3D Array and initialised it with random values ranging from 10 to 99

    // now printing that 3D Array

    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            for (int k = 0; k < p; k++)
            {
                cout << arr[i][j][k] << " ";
            }
            cout << endl;
        }
    }

    cout << endl;

    scalar_val(arr, m, n, p);
    cout << "The transpose of our 3D Array is " << endl;
    cout << endl;
    transpose(arr, m, n, p);

    // now we want to dynamically create a 3D array for tranposed matrix
    int ***transposed_arr = new int **[m];
    for (int i = 0; i < m; i++)
    {
        transposed_arr[i] = new int *[p];
        for (int j = 0; j < p; j++)
        {
            transposed_arr[i][j] = new int[n];
            for (int k = 0; k < n; k++)
            {
                transposed_arr[i][j][k] = arr[i][k][j];
            }
        }
    }

    deallocation(arr, m, n, p);

    // deallocated the memory for original matrix and then linked tranpose matrix to original matrix pointer
    arr = transposed_arr;
    deallocation(transposed_arr, m, n, p);

    return 0;
}

void scalar_val(int ***arr, int m, int n, int p)
{
    int scalar;
    int op;
    while (true)
    {
        cout << "Enter any scalar number " << endl;
        cin >> scalar;
        cout << "Enter the operand " << endl;
        cout << "Press 1 for Addition " << endl;
        cout << "Press 2 for Subtraction " << endl;
        cout << "Press 3 for Multiplication " << endl;
        cout << "Press 4 for Division " << endl;
        cin >> op;
        if (scalar != 0 && op != 4)
            break;
        else
            cout << "Math Error. Enter a possible combination " << endl;
        cout << endl;
    }
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            for (int k = 0; k < p; k++)
            {
                if (op == 1)
                    cout << scalar + arr[i][j][k] << " ";
                if (op == 2)
                    cout << arr[i][j][k] - scalar << " ";
                if (op == 3)
                    cout << scalar * arr[i][j][k] << " ";
                if (op == 4)
                    cout << arr[i][j][k] / scalar << " ";
            }
            cout << endl;
        }
    }
}

void transpose(int ***arr, int m, int n, int p)
{
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            for (int k = 0; k < p; k++)
            {
                cout << arr[i][k][j] << " ";
            }
            cout << endl;
        }
    }
}

void deallocation(int ***arr, int m, int n, int p)
{
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            delete[] arr[i][j];
        }
        delete arr[i];
    }
    delete arr;
}
